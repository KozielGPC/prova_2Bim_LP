
package Main;

public class Professor {

    private int ID;
    private String Nome;
    private String Email;
    private String Nascimento ;

    public Professor() {
    }

    public Professor(int ID, String Nome, String Email, String Nascimento) {

        this.ID = ID;
        this.Nome = Nome;
        this.Email = Email;
        this.Nascimento = Nascimento;
    }

    @Override
    public String toString() {
        return "Contato{" + "ID=" + ID + ", Nome=" + Nome + ", Email=" + Email
                + ", Nascimento=" + Nascimento + '}';
    }

    
    
  
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
    public String getNascimento() {
        return Nascimento;
    }

    public void setNascimento(String Nascimento) {
        this.Nascimento = Nascimento;
    }

    



   
    
    
}
