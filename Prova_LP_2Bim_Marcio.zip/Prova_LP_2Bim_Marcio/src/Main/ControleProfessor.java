package Main;

import java.util.ArrayList;
import java.util.List;


public class ControleProfessor {

    List<Professor> lista = new ArrayList<>();

    public ControleProfessor() {
   
    }

    public Professor buscar(int chave) {
        for (int i = 0; i < lista.size(); i++) {
            if (chave==lista.get(i).getID()) {
                return lista.get(i);//se encontrou, retorna a linha toda (um contato)
            }
        }
        return null; //se não encontrou na lista, retorna um contato nulo
    }

    public void inserir(Professor professor) {
        lista.add(professor);
    }

    void alterar(Professor contatoOriginal, Professor contatoAlterado) {
        lista.set(lista.indexOf(contatoOriginal), contatoAlterado);
    }

    public List<String> listar() {
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            ls.add(""
                    + lista.get(i).getID() + ";"
                    + lista.get(i).getNome() + ";"
                    + lista.get(i).getEmail() + ";"
                    + lista.get(i).getNascimento() 
           );
        }
        return ls;
    }
    
    public void excluir(Professor professor){
        lista.remove(professor);
    }

}
