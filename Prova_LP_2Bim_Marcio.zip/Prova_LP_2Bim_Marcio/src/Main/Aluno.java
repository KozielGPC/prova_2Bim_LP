
package Main;

public class Aluno {
    
    private int RA;
    private String nome;
    private String Email;
    private String Nascimento;
    private String Periodo;

    public Aluno() {
    }

    public Aluno(int RA, String nome, String Email, String Nascimento, String Periodo) {
        this.RA = RA;
        this.nome = nome;
        this.Email =  Email;
        this.Nascimento = Nascimento;
        this.Periodo = Periodo;
    }

    @Override
    public String toString() {
        return "Contato{" + "RA=" + RA 
                + ", nome=" + nome  + ", Email=" + Email + ", Nascimento="+Nascimento+ ", Periodo=" + Periodo +  '}';
    }

    
    public int getRA() {
        return RA;
    }

    public void setRA(int RA) {
        this.RA = RA;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getNascimento() {
        return Nascimento;
    }

    public void setNascimento(String Nascimento) {
        this.Nascimento = Nascimento;
    }
    public String getPeriodo() {
        return Periodo;
    }

    public void setPeriodo(String Periodo) {
        this.Periodo = Periodo;
    }


    



   
    
    
}
