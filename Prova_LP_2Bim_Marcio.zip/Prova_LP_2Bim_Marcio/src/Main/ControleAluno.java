package Main;

import java.util.ArrayList;
import java.util.List;


public class ControleAluno {

    List<Aluno> lista = new ArrayList<>();

    public ControleAluno() {
   
    }

    public Aluno buscar(int chave) {
        for (int i = 0; i < lista.size(); i++) {
            if (chave==lista.get(i).getRA()) {
                return lista.get(i);//se encontrou, retorna a linha toda (um contato)
            }
        }
        return null; //se não encontrou na lista, retorna um contato nulo
    }

    public void inserir(Aluno contato) {
        lista.add(contato);
    }


    void alterar(Aluno contatoOriginal, Aluno contatoAlterado) {
        lista.set(lista.indexOf(contatoOriginal), contatoAlterado);
    }

    public List<String> listar() {
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            ls.add(""
                    + lista.get(i).getRA() + ";"
                    + lista.get(i).getNome() + ";"
                    + lista.get(i).getEmail() + ";"
                    + lista.get(i).getNascimento() + ";"
                    + lista.get(i).getPeriodo()
           );
        }
        return ls;
    }
    
    public void excluir(Aluno contato){
        lista.remove(contato);
    }
}
