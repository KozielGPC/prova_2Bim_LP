package Main;

import java.util.ArrayList;
import java.util.List;


public class ControleMateria {

    List<Materia> lista = new ArrayList<>();

    public ControleMateria() {
   
    }

    public Materia buscar(int chave) {
        for (int i = 0; i < lista.size(); i++) {
            if (chave==lista.get(i).getID()) {
                return lista.get(i);//se encontrou, retorna a linha toda (um contato)
            }
        }
        return null; //se não encontrou na lista, retorna um contato nulo
    }

    public void inserir(Materia contato) {
        lista.add(contato);
    }

    void alterar(Materia contatoOriginal, Materia contatoAlterado) {
        lista.set(lista.indexOf(contatoOriginal), contatoAlterado);
    }

    public List<String> listar() {
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            ls.add(""
                    + lista.get(i).getID() + ";"
                    + lista.get(i).getNome() + ";"
                    + lista.get(i).getCarga() + ";"
                    + lista.get(i).getProfessor() 
            );
        }
        return ls;
    }
    
    public void excluir(Materia contato){
        lista.remove(contato);
    }

}
