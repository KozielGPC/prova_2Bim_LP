
package Main;

public class Materia {

    private int ID;
    private String Nome;
    private String Carga;
    private String Professor;

    public Materia() {
    }

    public Materia(int ID, String Nome, String Carga, String Professor) {

        this.ID = ID;
        this.Nome = Nome;
        this.Carga = Carga;
        this.Professor = Professor;
    }

    @Override
    public String toString() {
        return "Contato{" + "ID=" + ID + ", Nome=" + Nome + ", Carga Horária=" + Carga
                + ", Professor=" + Professor + '}';
    }

    
    
  
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getCarga() {
        return Carga;
    }

    public void setCarga(String Carga) {
        this.Carga = Carga;
    }
    public String getProfessor() {
        return Professor;
    }

    public void setProfessor(String Professor) {
        this.Professor = Professor;
    }
    



   
    
    
}
